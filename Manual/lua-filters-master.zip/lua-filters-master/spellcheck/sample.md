---
lang: fr-FR
...

Ces sont des mots français.
Mais pas summer.

[This is a sentence in English,
with one missspeling.]{lang=en}

::: {lang=en}
Here's a div in English.
Code is ignored: `baoeuthasoe`{.nolang}.
So are [URLs](http://example.com/notaword).
:::
