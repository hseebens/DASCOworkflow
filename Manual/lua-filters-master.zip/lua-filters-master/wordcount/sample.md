---
title: Metadata words don't count
abstract: ignored!
---

# Word count

This document has *a **lot** of [words](url "title")* (15).[^1]

    code is counted

[^1]: Footnotes count.
