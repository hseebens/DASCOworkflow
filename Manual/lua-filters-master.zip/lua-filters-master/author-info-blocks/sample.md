---
author:
- correspondence: yes
  email: 'jane.doe\@example.com'
  equal_contributor: yes
  id: Jane Doe
  institute:
  - 1
  name: Jane Doe
- equal_contributor: yes
  id: 'John Q. Doe'
  institute:
  - 1
  - 2
  name: 'John Q. Doe'
- id: Juan Pérez
  institute:
  - 2
  name: Juan Pérez
institute:
- id: federation
  name: Federation of Planets
- id: acme
  name: Acme Corporation
title: Affiliation Blocks Example
---

Lorem ipsum dolor sit amet.
