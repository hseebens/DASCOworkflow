---
title: Multiple Bibliographies Demo
bibliography_sources: primary.bib
bibliography_recommended_reading: secondary.bib
nocite: '@Knu86, @Bae'
---
@Nie72, @Bel

# References

::: {#refs_sources}
:::

# Recommended Reading

::: {#refs_recommended_reading}
:::
