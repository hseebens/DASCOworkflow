---
bibliography:
  - 'my_refs.bib'
  - '__from_DOI.bib'
---

# Introduction
The Laemmli system is one of the most widely used gel systems for the separation of proteins.[@LAEMMLI_1970]
By the way, Einstein is genius.[@https://doi.org/10.1002/andp.19053220607; @doi.org/10.1002/andp.19053220806; @doi:10.1002/andp.19053221004]