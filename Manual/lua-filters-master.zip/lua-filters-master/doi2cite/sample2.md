---
bibliography:
  - "my_refs.bib"
  - "__from_DOI.bib"
---

# Introduction
People sometimes make mistakes.[@DOI:10.1002/THIS.IS.NOT.VALID.DOI.SAMPLE]