---
author: Jane Doe
fromaddress:
  - 35 Industry Way
  - Springfield
opening: To Whom It May Concern,
subject: Letter of Reference
date: February 29, 2020
address:
  - Fireworks Inc.
  - 123 Fake St
  - 58008 Springfield
...

I strongly recommend to embiggen your team by giving John Doe the position of a
yak shaver. He has shown cromulent performance as a bike shedder.
