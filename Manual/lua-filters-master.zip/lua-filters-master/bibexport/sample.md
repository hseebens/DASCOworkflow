---
bibliography:
- sample.bib
- coffee.bib
...

# Abstract

This is an example article. It was written under the influence of
coffee, which acts to counter fatigue [@Li95].


# Further reading

Authors struggling to fill their document with content are referred to
@Upper_writers_1974.

# References
