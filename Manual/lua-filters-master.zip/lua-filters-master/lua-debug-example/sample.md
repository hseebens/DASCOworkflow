# Lua Debug Example

Lorem *ipsum* dolor sit amet, **consectetuer** adipiscing elit. Donec
hendrerit tempor tellus. Donec pretium posuere tellus.  

Cum sociis natoque *penatibus* et magnis dis parturient montes,
nascetur ridiculus mus. **Nulla posuere**. Donec vitae dolor.  

