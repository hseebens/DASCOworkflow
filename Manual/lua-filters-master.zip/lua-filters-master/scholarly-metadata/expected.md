---
author:
- id: Jane Doe
  institute:
  - 1
  - 2
  name: Jane Doe
- id: John Q. Doe
  institute:
  - 1
  name: John Q. Doe
- id: Peder Ås
  institute:
  - 1
  name: Peder Ås
- id: Juan Pérez
  institute:
  - 3
  name: Juan Pérez
- id: Max Mustermann
  name: Max Mustermann
institute:
- address: 23 Science Street, Eureka, Mississippi, USA
  id: fosg
  index: 1
  name: Formatting Open Science Group
- id: fop
  index: 2
  name: Federation of Planets
- id: Acme Corporation
  index: 3
  name: Acme Corporation
---

# Abstract

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
occaecat cupidatat non proident, sunt in culpa qui officia deserunt
mollit anim id est laborum.
