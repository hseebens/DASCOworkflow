These "marks" should be left alone.
These 'marks' too.
