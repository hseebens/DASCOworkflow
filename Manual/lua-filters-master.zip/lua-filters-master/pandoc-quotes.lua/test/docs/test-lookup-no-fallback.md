---
quot-marks-by-lang:
    xxx-zz:
        - LDQUO
        - RDQUO
        - LSQUO
        - RSQUO
quot-lang: xxx-yy
...

This is a "not so simple" test.
For single 'quotes', too.
